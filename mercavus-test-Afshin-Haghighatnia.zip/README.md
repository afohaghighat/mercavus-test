# mercavus-test

To install the app please use:<br/>
<b>npm install</b>


To run the application use:</br>
<b>npm start</b>


To run server api, please run:<br/>
<b>npm run mock:api</b>


To run tests, please run:<br/>
<b>npm test</b>

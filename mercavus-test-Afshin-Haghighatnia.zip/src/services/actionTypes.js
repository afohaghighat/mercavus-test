//Users
export const GET_USERS = "GET_USERS";
export const ADD_USER = "ADD_USER";
export const UPDATE_USER = "UPDATE_USER";
export const DELETE_USER = "DELETE_USER";

//Hobbies
export const GET_USER_HOBBIES = "GET_USER_HOBBIES";
export const ADD_USER_HOBBY = "ADD_USER_HOBBY";
export const UPDATE_USER_HOBBY = "UPDATE_USER_HOBBY";
export const DELETE_USER_HOBBY = "DELETE_USER_HOBBY";

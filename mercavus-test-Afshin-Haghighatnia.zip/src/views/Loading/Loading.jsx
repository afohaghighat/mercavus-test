import React from "react";
// import { Spinner } from "ui-kit";

const Loading = () => <span className="animated fadeIn inline-loader pt-3 text-center">{/* <Spinner /> */}</span>;

export default Loading;
